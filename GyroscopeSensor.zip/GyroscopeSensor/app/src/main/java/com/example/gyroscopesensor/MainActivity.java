package com.example.gyroscopesensor;

import androidx.appcompat.app.AppCompatActivity;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    Sensor gyroscopeSensor;
    SensorEventListener gyroscopeSensorListener;
    SensorManager sensorManager;
    ImageView animateView;
    String tag="Gyroscope Sensors";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        animateView = findViewById(R.id.imageView);
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        gyroscopeSensor = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
    }
    public void onResume() {

        super.onResume();

        if(gyroscopeSensor == null ) {
            Log.e(tag, "Gyroscope sensor is not available.");
            finish(); // Close app
        }

        // Create a listener
        gyroscopeSensorListener = new SensorEventListener() {
            @Override
            public void onSensorChanged(SensorEvent sensorEvent) {
                if(sensorEvent.values[1] > 0.5f) {
                    animateView.setImageResource(R.drawable.green_circle);
                } else if(sensorEvent.values[1] < -0.5f) {
                    animateView.setImageResource(R.drawable.circle);
                }
            }

            @Override
            public void onAccuracyChanged(Sensor sensor, int i) {
            }
        };

// Register the listener
        sensorManager.registerListener(gyroscopeSensorListener,
                gyroscopeSensor, SensorManager.SENSOR_DELAY_NORMAL);



    }
    public void onPause() {

        super.onPause();
        sensorManager.unregisterListener(gyroscopeSensorListener);
        Log.d(tag,"I am running onPause()");
    }
}
